namespace MASZ.Dtos.Tokens
{
    public class CreatedTokenDto
    {
        public int Id { get; set; }
        public string Token { get; set; }
    }
}