﻿namespace MASZ.Utils
{
	public interface IEvent
	{

		public void RegisterEvents();

	}
}
