namespace MASZ.Models
{
    interface IDomainList
    {
        public string[] ReloadDomainList();
    }
}