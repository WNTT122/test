namespace MASZ.Models
{
    public class ModeratorCaseCount
    {
        public ulong ModId { get; set; }
        public int Count { get; set; }
    }
}
