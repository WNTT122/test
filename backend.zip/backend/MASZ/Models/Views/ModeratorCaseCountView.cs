namespace MASZ.Models
{
    public class ModeratorCaseCountView
    {
        public string ModId { get; set; }
        public string ModName { get; set; }
        public int Count { get; set; }
    }
}
