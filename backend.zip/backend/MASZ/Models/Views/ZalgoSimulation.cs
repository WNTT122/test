using MASZ.Models.Views;

namespace MASZ.Models
{
    public class ZalgoSimulation
    {
        public string oldName { get; set; }
        public string newName { get; set; }
        public DiscordUserView user { get; set; }
    }
}
