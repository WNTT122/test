using MASZ.Enums;

namespace MASZ.Models
{
    public class AutoModerationTypeSplit
    {
        public AutoModerationType Type { get; set; }
        public int Count { get; set; }
    }
}
