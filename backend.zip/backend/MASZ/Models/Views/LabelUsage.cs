﻿namespace MASZ.Models
{
    public class LabelUsage
    {
        public string Label { get; set; }
        public int Count { get; set; }
    }
}
