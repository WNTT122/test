namespace MASZ.Enums
{
    public enum MarkedToDeleteStatus
    {
        None,
        Unmarked,
        Marked
    }
}