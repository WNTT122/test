namespace MASZ.Enums
{
    public enum CaseCreationType
    {
        Default,
        AutoModeration,
        Imported,
        ByCommand
    }
}