﻿namespace MASZ.Enums
{
    public enum ScheduledMessageStatus
    {
        Pending,
        Sent,
        Failed
    }
}
