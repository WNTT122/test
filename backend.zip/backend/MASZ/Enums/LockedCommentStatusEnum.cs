namespace MASZ.Enums
{
    public enum LockedCommentStatus
    {
        None,
        Unlocked,
        Locked
    }
}