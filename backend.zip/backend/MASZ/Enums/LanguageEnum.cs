namespace MASZ.Enums
{
    public enum Language
    {
        en,
        de,
        fr,
        es,
        it,
        at,
        ru,
        nl,
    }
}