namespace MASZ.Enums
{
    public enum EditStatus
    {
        None,
        Unedited,
        Edited
    }
}