namespace MASZ.Enums
{
    public enum DiscordPermission
    {
        Member,
        Moderator,
        Admin
    }
}