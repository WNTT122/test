namespace MASZ.Enums
{
    public enum AutoModerationType
    {
        InvitePosted,
        TooManyEmotes,
        TooManyMentions,
        TooManyAttachments,
        TooManyEmbeds,
        TooManyAutoModerations,
        CustomWordFilter,
        TooManyMessages,
        TooManyDuplicatedCharacters,
        TooManyLinks,
        TooManyPhishingLinks,
    }
}
