namespace MASZ.Enums
{
    public enum RestAction
    {
        Created,
        Updated,
        Deleted
    }
}
