namespace MASZ.Enums
{
    public enum GuildFeatureTestResult
    {
        Ok,
        RoleUnknown,
        RoleTooHigh
    }
}