namespace MASZ.Enums
{
    public enum AppealStatus
    {
        Pending = 0,
        Approved = 1,
        Declined = 2
    }
}