namespace MASZ.Enums
{
    public enum PunishmentType
    {
        Warn,
        Mute,
        Kick,
        Ban
    }
}