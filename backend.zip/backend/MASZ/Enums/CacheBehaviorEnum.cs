namespace MASZ.Enums
{
    public enum CacheBehavior
    {
        OnlyCache,
        Default,
        IgnoreCache,
        IgnoreButCacheOnError
    }
}