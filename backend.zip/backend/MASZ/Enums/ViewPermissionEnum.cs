namespace MASZ.Enums
{
    public enum ViewPermission
    {
        Global,
        Guild,
        Self
    }
}