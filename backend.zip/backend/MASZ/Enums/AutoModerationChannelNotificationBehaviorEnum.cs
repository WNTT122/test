namespace MASZ.Enums
{
    public enum AutoModerationChannelNotificationBehavior
    {
        SendNotification,
        SendNotificationAndDelete,
        NoNotification
    }
}