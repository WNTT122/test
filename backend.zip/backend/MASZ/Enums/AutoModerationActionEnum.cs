namespace MASZ.Enums
{
    public enum AutoModerationAction
    {
        None,
        ContentDeleted,
        CaseCreated,
        ContentDeletedAndCaseCreated,
        Timeout
    }
}