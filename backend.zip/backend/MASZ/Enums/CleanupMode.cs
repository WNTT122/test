namespace MASZ.Enums
{
    public enum CleanupMode
    {
        Attachments,
        Bots,
        Messages
    }
}