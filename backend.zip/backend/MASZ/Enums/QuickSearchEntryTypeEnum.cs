namespace MASZ.Enums
{
    public enum QuickSearchEntryType
    {
        ModCase,
        AutoModeration
    }
}