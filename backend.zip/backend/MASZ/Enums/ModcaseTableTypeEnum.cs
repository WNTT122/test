namespace MASZ.Enums
{
    public enum ModcaseTableType
    {
        Default,
        OnlyPunishments,
        OnlyBin
    }
}