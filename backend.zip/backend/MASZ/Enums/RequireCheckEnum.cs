namespace MASZ.Enums
{
    public enum RequireCheckEnum
    {
        None,
        GuildRegistered,
        GuildMember,
        GuildModerator,
        GuildAdmin,
        GuildMuteRole,
        SiteAdmin,
        GuildStrictModeMute,
        GuildStrictModeKick,
        GuildStrictModeBan
    }
}