﻿namespace MASZ.Enums
{
    public enum ScheduledMessageFailureReason
    {
        Unknown,
        ChannelNotFound,
        InsufficientPermission
    }
}
