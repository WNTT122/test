namespace MASZ.Enums
{
    public enum ModcaseTableSortType
    {
        Default,
        SortByExpiring,
        SortByDeleting
    }
}