namespace MASZ.Enums
{
    public enum PunishmentActiveStatus
    {
        None,
        Inactive,
        Active
    }
}