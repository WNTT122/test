namespace MASZ.Enums
{
    public enum APIActionPermission
    {
        View,
        Edit,
        Delete,
        ForceDelete
    }
}