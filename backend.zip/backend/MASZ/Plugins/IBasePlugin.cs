namespace MASZ.Plugins
{
    public interface IBasePlugin
    {
        void Init();
    }
}
